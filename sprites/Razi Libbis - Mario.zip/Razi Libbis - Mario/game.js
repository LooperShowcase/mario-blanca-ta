kaboom({
  global: true,
  fullscreen: true,
  clearColor: [0, 0.6, 0.9, 1],
  debug: true,
  scale: 2,
});

loadRoot("./sprites/");
loadSprite("block", "block.png");
loadSprite("grass", "grass.png");
loadSprite("surprise", "surprise.png")
loadSprite("pipe_up", "pipe_up.png")
loadSprite("mario", "mario.png");
loadSprite("coin", "coin.png");
loadSprite("e_m", "evil_mushroom.png");
loadSprite("pipe", "pipe_up.png");
loadSprite("suprise", "surprise.png");
loadSprite("unboxed", "unboxed.png");
loadSprite("cloud", "cloud.png");
loadSprite("mushroom", "mushroom.png")
loadSound("gameSound", "gameSound.mp3");
loadSound("jumpSound", "jumpSound.mp3");

scene("over", () => {});

const jumpForce = 450
const speed = 222   

scene("game", () => 
{
  layers(["bg", "obj", "ui"], "obj");
  play("gameSound")

    const key = {
        width:20,
        height:20,
        "=": [sprite("block"), solid()],
        "c": [sprite("cloud"), scale(2), layer("bg")],
        "*": [sprite("grass"), layer("bg")],
        "?": [sprite("surprise"), solid(), 'surprise-coin'],
        "!": [sprite("surprise"), solid(), 'surprise-mushroom'],
        "&": [sprite("mushroom")],
        "$": [sprite("coin")],
        "x": [sprite('unboxed'), solid()],
        "p": [sprite("pipe_up", solid())]


    }
    
    const map = [
        "                                       ",
        "                                       ",
        "c                                      ",
        "              c                        ",
        "           =!=                         ",
        "                                       ",
        "                                       ",
        "                                       ",
        "                                       ",
        "       ===?===     ?      ===          ",
        "                                       ",
        "       *                     *         ",
        "                       p               ",
        "                                       ",
        "=======================================",
        "=======================================",
        "=======================================",
        "=======================================",
        "=======================================",
        "=======================================",
        "=======================================",
        "=======================================",
        "=======================================", 

    ]
    const player= add([
          sprite("mario"),
          solid(),
          pos(55,0),
          body(),
          origin("bot"),
          scale(1.5)
          
    ])
    const gameLevel = addLevel(map,key)

    keyDown('d', () =>{ 
       player.move(speed , 0);  
    });


    keyDown('a', () =>{
      if(player.pos.x > 10)
      {
        player.move(-speed , 0);
      }
    });

    keyDown('w', () =>{ 
      if(player.grounded())
      {
        player.jump(jumpForce)
        play("jumpSound")
      }
      
    })
    player.on("headbump", (obj) => {
      console.log("bump");
      if(obj.is("surprise-coin")){
       gameLevel.spawn("$", obj.gridPos.sub(0, 1))
       destroy(obj)
       gameLevel.spawn("x", obj.gridPos)  
      }
      if(obj.is("surprise-mushroom")){
        gameLevel.spawn("&", obj.gridPos.sub(0, 1))
        destroy(obj)
        gameLevel.spawn("x", obj.gridPos)
      }
    })
    
});
start("game");